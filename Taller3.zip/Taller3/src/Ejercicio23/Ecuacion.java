/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio23;

/**
 *
 * @author user
 */
public class Ecuacion {
    public static String metodo_ecuacion(double a, double b, double c) {
        double potencia, r1, r2;
        String respuesta;

         potencia = Math.pow(b, 2) - (4 * a * c);
        r1 = (-b - Math.sqrt(potencia) / 2 * a);
        r2 = (-b + Math.sqrt(potencia) / 2 * a);
        
        respuesta= "Las soluciones de la ecuacion son: " + r1 + " y " + r2;
        
        return respuesta;
        }
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicio18;

/**
 *
 * @author user
 */
public class IUEmpleado1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Formulario fr = new Formulario();
        fr.setVisible(true);

    }
    
}

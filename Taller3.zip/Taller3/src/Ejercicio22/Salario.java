/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
    package Ejercicio22;

    /**
     *
     * @author user
     */
    public class Salario {

        public static String metodo_salario(double salario_hora, double horas_trabajadas, String nombre) {
            double salario_mensual;
            String mensaje;
            salario_mensual = salario_hora * horas_trabajadas;

            if (salario_mensual > 450000) {
                mensaje = "Hola, " + nombre + "tu salario este mes es " + salario_mensual;
            } else {
                mensaje = "Hola" + nombre + "tu salario mensual es menor que 450000";
            }

            return mensaje;
        }
    }

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller3_parte2;

/**
 *
 * @author user
 */
public class FigurasGeometricas {

    double radio_circulo, lado_cuadrado, base_rectangulo, altura_rectangulo, lado_rombo, diagonal1_rombo, diagonal2_rombo, lado_traecio,
            baseMayor_trapecio, baseMenor_trapecio, altura_trapecio, base_triangulor, altura_triangulor;

    //Area y perimetro del circulo
    public static double area_circulo(double radio_circulo) {
        return Math.PI * Math.pow(radio_circulo, 2);
    }

    public static double perimetro_circulo(double radio_circulo) {
        return 2 * Math.PI * radio_circulo;
    }

    //Area y perimetro del cuadrado
    public static double area_cuadrado(double lado_cuadrado) {
        return lado_cuadrado * lado_cuadrado;
    }

    public static double perimetro_cuadrado(double lado_cuadrado) {
        return (4 * lado_cuadrado);
    }

    //Area y perimetro del rectangulo
    public static double area_rectangulo(double base_rectangulo, double altura_rectangulo) {
        return base_rectangulo * altura_rectangulo;
    }

    public static double perimetro_rectangulo(double base_rectangulo, double altura_rectangulo) {
        return (2 * base_rectangulo) + (2 * altura_rectangulo);
    }

    //Area y perimetro del rombo
    public static double area_rombo(double lado_rombo, double diagonal1_rombo, double diagonal2_rombo) {
        return (diagonal1_rombo * diagonal2_rombo) / 2;
    }

    public static double perimetro_rombo(double lado_rombo, double diagonal1_rombo, double diagonal2_rombo) {
        return (4 * lado_rombo);
    }

    //Area y perimetro del trapecio
    public static double area_trapecio(double lado_traecio, double baseMayor_trapecio, double baseMenor_trapecio, double altura_trapecio) {
        return ((baseMayor_trapecio + baseMenor_trapecio) / 2) * altura_trapecio;
    }

    public static double perimetro_trapecio(double lado_traecio, double baseMayor_trapecio, double baseMenor_trapecio, double altura_trapecio) {
        return (baseMayor_trapecio + baseMenor_trapecio + (2 * lado_traecio));

    }

    //Area perimetro, hipotenusa y tipo de triangulo del triangulo rectangulo
    public static double area_triangulor (double base_triangulor, double altura_triangulor) {
         return (base_triangulor * altura_triangulor / 2);
    }

    public static double perimetro_triangulor (double base_triangulor, double altura_triangulor) {
        return (base_triangulor + altura_triangulor + Math.pow(base_triangulor * base_triangulor + altura_triangulor * altura_triangulor, 0.5));
    }
        public static double calcularHipotenusa(double base_triangulor, double altura_triangulor) {
        return Math.pow(base_triangulor * base_triangulor + altura_triangulor * altura_triangulor, 0.5);
    }
    
    public static String tipo_triangulor (double base_triangulor, double altura_triangulor) {
        String tipoTrianguloR;
        if ((base_triangulor == altura_triangulor) && (base_triangulor == (Math.pow(base_triangulor * base_triangulor + altura_triangulor * altura_triangulor, 0.5))) && (altura_triangulor == (Math.pow(base_triangulor * base_triangulor + altura_triangulor * altura_triangulor, 0.5)))) {
            tipoTrianguloR= "Es un triángulo equilátero";

        } else if ((base_triangulor != altura_triangulor) && (base_triangulor != (Math.pow(base_triangulor * base_triangulor + altura_triangulor * altura_triangulor, 0.5))) && (altura_triangulor != (Math.pow(base_triangulor * base_triangulor + altura_triangulor * altura_triangulor, 0.5)))) {
            tipoTrianguloR="Es un triángulo escaleno";
        } else {
            tipoTrianguloR="Es un triángulo isósceles";
        }
 return tipoTrianguloR;
    }
}

